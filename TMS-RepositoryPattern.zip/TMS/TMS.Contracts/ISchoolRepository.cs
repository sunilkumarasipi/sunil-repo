﻿using System;
using System.Collections.Generic;
using System.Text;
using TMS.Data.Models;

namespace TMS.Contracts
{
    public interface ISchoolRepository : IRepository<School>
    {
    }
}
