﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TMS.Contracts;
using TMS.Data.Models;

namespace TMS.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SchoolController : ControllerBase
    {
        private readonly IUnitOfWork _uow;
        public SchoolController(IUnitOfWork uow)
        {
            _uow = uow;
        }
        // GET: api/School
        [HttpGet]
        public IEnumerable<School> GetSchool()
        {
            return _uow.SchoolRepository.Get();
        }

        // GET: api/School/5
        [HttpGet("{id}")]
        public ActionResult<School> GetSchool(int id)
        {
            var school = _uow.SchoolRepository.GetById(id);

            if (school == null)
            {
                return NotFound();
            }

            return school;
        }

        // PUT: api/School/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPut("{id}")]
        public IActionResult PutSchool(int id, School School)
        {
            if (id != School.SchoolId)
            {
                return BadRequest();
            }
            try
            {
                _uow.SchoolRepository.Update(School);
                _uow.Commit();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!SchoolExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/School
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPost]
        public ActionResult<School> PostSchool(School School)
        {
            _uow.SchoolRepository.Add(School);
            _uow.Commit();
            return CreatedAtAction("GetSchool", new { id = School.SchoolId }, School);
        }

        // DELETE: api/School/5
        [HttpDelete("{id}")]
        public ActionResult<School> DeleteSchool(int id)
        {
            var school = _uow.SchoolRepository.GetById(id);
            if (school == null)
            {
                return NotFound();
            }

            _uow.SchoolRepository.Delete(school);
            _uow.Commit();
            return school;
        }

        private bool SchoolExists(int id)
        {
            var _school = _uow.SchoolRepository.GetById(id);
            if (_school == null)
            {
                return false;
            }
            return true;
        }
    }
}
