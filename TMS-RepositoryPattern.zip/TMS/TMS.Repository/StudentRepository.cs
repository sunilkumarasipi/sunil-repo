﻿using System;
using System.Collections.Generic;
using System.Text;
using TMS.Contracts;
using TMS.Data;
using TMS.Data.Models;

namespace TMS.Repository
{
    public class StudentRepository : Repository<Student>, IStudentRepository
    {
        public StudentRepository(AppDBContext _dbContext) :base(_dbContext)
        {

        }
    }
}
